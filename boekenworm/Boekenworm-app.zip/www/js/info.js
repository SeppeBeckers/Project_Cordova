let Info = function () {
    let init = function () {

};
    return {
        init: init
    };
}();